var SampleCustomDialogStringTable = {
    enterText                       : "Wprowadź tekst",
    sampleCustDialogTitle           : "Przykładowe okienko użytkownika",
    sampleCustDialogBody            : "To jest po prostu przykładowe okienko",
    okay                            : "OK"
};
