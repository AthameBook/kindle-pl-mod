var SearchDomainStringTable = {
    domainLabels: {
        title_author: 'Moje pozycje',
        unified: 'Wszystkie pozycje',
        catalog: 'Cały tekst',
        store: 'Sklep Kindle',
        google: 'Google',
        dictionary: 'Słownik',
        discovery: 'Goodreads',
        website: 'Adres internetowy',
        baiduSearch: 'Baidu',
        deviceSearch: 'Czytnik'
    },
    // Set the preferred value in pt, Eg. offsetWidth: '100pt', if not leave it as null
    // localization can use this to force a width in a given locale if it needs to. 
    offsetWidth: null,
};
