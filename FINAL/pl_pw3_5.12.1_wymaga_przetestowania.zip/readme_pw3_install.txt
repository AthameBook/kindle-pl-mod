Instrukcja ręcznej instalacji
1) skopiowanie pl_pw3_5_12_1 na głównego katalogu Kindle (/mnt/us/)
2) podłączenie Kindle przez usbnet
3) wykonanie poniższych instrukcji


[root@kindle ]# mntroot rw
[root@kindle ]# cd /mnt/us/pl_pw3_5_12_1/opt/amazon/ebook/
[root@kindle ebook]# cp -r config /opt/amazon/ebook/
[root@kindle ebook]# cp -r lib /opt/amazon/ebook/
[root@kindle ebook]# cp -r booklet /opt/amazon/ebook/
[root@kindle root]# cd /mnt/us/pl_pw3_5_12_1/usr/share/
[root@kindle share]# cp -r locale /usr/share/
[root@kindle share]# cp -r webkit-1.0 /usr/share/
[root@kindle share]# cd /mnt/us/pl_pw3_5_12_1/
[root@kindle pl_pw3_5_12_1]# cp KEYBOARD.tar.gz /
[root@kindle pl_pw3_5_12_1]# cd /
[root@kindle ]# tar xvf KEYBOARD.tar.gz
[root@kindle ]# rm KEYBOARD.tar.gz
[root@kindle ]# reboot
