Instrukcja ręcznej instalacji
1) skopiowanie pl_pw2_5_12_1 na głównego katalogu Kindle (/mnt/us/)
2) podłączenie Kindle przez usbnet
3) wykonanie poniższych instrukcji


[root@kindle root]# mntroot rw
system: I mntroot:def:Making root filesystem writeable
[root@kindle root]# cd /mnt/us/pl_pw2_5_12_1/opt/amazon/ebook/
[root@kindle ebook]# cp -r config /opt/amazon/ebook/
[root@kindle ebook]# cp -r lib /opt/amazon/ebook/
[root@kindle ebook]# cp -r booklet /opt/amazon/ebook/
[root@kindle root]# cd /mnt/us/pl_pw2_5_12_1/usr/share/
[root@kindle share]# cp -r locale /usr/share/
[root@kindle share]# cp -r locale /usr/share/
[root@kindle share]# cd /mnt/us/pl_pw2_5_12_1/
[root@kindle pl_pw2_5_12_1]# cp KEYBOARD-PW2.tar.gz /
[root@kindle pl_pw2_5_12_1]# cd /
[root@kindle ]# tar xvf KEYBOARD-PW2.tar.gz
tar: removing leading '/' from member names
usr/share/keyboard.sqsh
[root@kindle ]# rm KEYBOARD-PW2.tar.gz
[root@kindle ]# reboot
reboot: command arguments: no_sync=0, force=0, poweroff=0, exit_only=0, args=77104

Broadcast message from root@kindle
        (/dev/pts/1) at 14:52 ...

The system is going down for reboot NOW!
