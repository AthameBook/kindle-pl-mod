var AirplanemodeAccessibilityStringTable = {
    turnOnAirplaneModeDesc : 'Włącz tryb samolotowy, aby wyłączyć łączność bezprzewodową.',
    turnOffAirplaneModeDesc : 'Wyłącz tryb samolotowy, aby włączyć łączność bezprzewodową.',
    turnOnAirplaneModeLabel : 'WŁ.',
    turnOffAirplaneModeLabel : 'WYŁ.',
};
