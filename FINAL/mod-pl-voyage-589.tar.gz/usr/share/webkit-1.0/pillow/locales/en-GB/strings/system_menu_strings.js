
var SystemMenuItemStrings = {
    store: 'Zakupy w sklepie Kindle',
    settings: 'Ustawienia'
};

