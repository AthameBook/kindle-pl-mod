var nextButtonStringTable = {
	'displayname': 'Następny',
	'headertitle' : 'Wybierz format twojego regionu',
	'headerbody' : 'Spowoduje to zmianę formatowania dat, godzin itp.'
};

var demoCountryPickerStringTable = {
    'headertext': 'Proszę wybrać kraj dla trybu demonstracyjnego'
};
