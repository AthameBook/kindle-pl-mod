var nextButtonStringTable = {
    'firstPageName': 'WYBIERZ REGION',
    'finalPageName': 'POCZĄTEK',
    'headertitle' : 'Wybierz swój regionalny format',
    'headerbody' : 'Spowoduje to zmianę formatu daty, czasu, itp.'
};

var demoCountryPickerStringTable = {
    'headertext': 'Wybierz kraj dla trybu demo'
};
