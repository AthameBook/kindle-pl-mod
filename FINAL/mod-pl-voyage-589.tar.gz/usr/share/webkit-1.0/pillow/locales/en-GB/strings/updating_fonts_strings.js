var UpdatingFontsConfig = {
    title: "Uaktualnienie czcionek",
    message: "Czcionki na Twoim Kindle są aktualizowane. To może chwilę potrwać..."
};
