var MediaPlayerBarStringTable = {
    trackCountMessageFormat : new MessageFormat("Ścieżka {index,number,integer} z {count,number,integer}"),
    turnOff : "Wył.",
    unknownArtists : "Nieznany artysta",
    style : {
             widthInPixel_dnt : "{width}px",
             marginRight_dnt  :  "0 {right} 0 0"
            }
};
