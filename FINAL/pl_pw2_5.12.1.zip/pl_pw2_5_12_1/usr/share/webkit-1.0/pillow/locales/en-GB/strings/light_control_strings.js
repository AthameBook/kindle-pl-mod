
var LightControlStringTable = {
    explainHigh: 'W jasno oświetlonych pomieszczeniach użyj <u>wyższe</u> ustawienia.',
    explainLow: 'Użyj <u>niższe</u> ustawienia w ciemnych pomieszczeniach.',
    auto: 'Oświetlenie automatyczne',
    lightBooster: 'Max.',
    lightControlsText: 'ŚWIATŁO',
};

var LightControlAccessibilityStringTable = {
    increaseLabel: 'Oświetlenie {current} z {max}. Zwiększ poziom oświetlenia.',
    decreaseLabel: 'Oświetlenie {current} z {max}. Zmniejsz poziom oświetlenia.',
};
