
var QuickActionsStrings = {
    airplaneMode: 'Tryb samolotowy',
    syncAndCheck: 'Synchronizuj',
    settings: 'Wszystkie ustawienia',
};

