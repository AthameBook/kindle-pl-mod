var StatusBarStringTable = {
    activityIdConnecting : "Łączenie",
    activityIdConnected : "Połączono",
    titleTextSeparator : "\u00a0\u00b7\u00a0",
    minWidthForPrimary : 60,
};
